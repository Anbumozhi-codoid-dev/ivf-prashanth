import 'package:datepicker_dropdown/datepicker_dropdown.dart';
import 'package:dropdown_textfield/dropdown_textfield.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../Allnavigations/AllBlocDirectory.dart';
import '../../../Allnavigations/AllimportedDirectory.dart';
import '../../../Bloc/SalaryBloc.dart';
import '../../../Utils/AppTheme.dart';

class NoDueForm extends StatefulWidget {
  const NoDueForm({super.key});

  @override
  State<NoDueForm> createState() => _NoDueFormState();
}

class _NoDueFormState extends State<NoDueForm> {
  TextEditingController _empNameController = TextEditingController();
  TextEditingController _empCodeController = TextEditingController();
  TextEditingController _empDesignationController = TextEditingController();
  TextEditingController _empLocationController = TextEditingController();
  TextEditingController _empDepartmentController = TextEditingController();
  TextEditingController _empDateJoiningController = TextEditingController();
  TextEditingController _empOfficialMailIdController = TextEditingController();
  TextEditingController _empDateRelievingController = TextEditingController();
  TextEditingController _empPersonalContactController = TextEditingController();
  TextEditingController _empPersonalEmailController = TextEditingController();
  SingleValueDropDownController _knowledgeController =
      SingleValueDropDownController();
  SingleValueDropDownController _backupController =
      SingleValueDropDownController();
  SingleValueDropDownController _otherHandOverController = SingleValueDropDownController();
  SingleValueDropDownController _ClearanceController = SingleValueDropDownController();
  SingleValueDropDownController _salaryAdvanceController = SingleValueDropDownController();
  SingleValueDropDownController _otherAdvanceController = SingleValueDropDownController();
  SingleValueDropDownController _pettyCashController = SingleValueDropDownController();
  SingleValueDropDownController _settleExpensesController = SingleValueDropDownController();
  SingleValueDropDownController _itDocController = SingleValueDropDownController();
  SingleValueDropDownController _happyAccountController = SingleValueDropDownController();
  SingleValueDropDownController _laptopController = SingleValueDropDownController();
  SingleValueDropDownController _cardAccessoriesController = SingleValueDropDownController();
  SingleValueDropDownController _sapLoginController = SingleValueDropDownController();
  SingleValueDropDownController _emailIdController = SingleValueDropDownController();
  SingleValueDropDownController _loginIdController = SingleValueDropDownController();
  SingleValueDropDownController _idAccessCardController = SingleValueDropDownController();
  SingleValueDropDownController _drawKeyController = SingleValueDropDownController();
  SingleValueDropDownController _businessCardController = SingleValueDropDownController();
  SingleValueDropDownController _headsetController = SingleValueDropDownController();
  SingleValueDropDownController _simController = SingleValueDropDownController();
  SingleValueDropDownController _stationaryItemsController = SingleValueDropDownController();
  SingleValueDropDownController _chargerCableController = SingleValueDropDownController();
  SingleValueDropDownController _medicalClaimController = SingleValueDropDownController();
  SingleValueDropDownController _exitInterviewController = SingleValueDropDownController();
  SingleValueDropDownController _resignMailController = SingleValueDropDownController();
  SingleValueDropDownController _noticePeriodController = SingleValueDropDownController();
  SingleValueDropDownController _relevantController = SingleValueDropDownController();
  SingleValueDropDownController _companyPropertyController = SingleValueDropDownController();


  String? selectedOption;
  int? _selectedJoiningDay;
  int? _selectedJoiningMonth;
  int? _selectedJoiningYear;

  int? _selectedRelievingDay;
  int? _selectedRelievingMonth;
  int? _selectedRelievingYear;


  String? kt;
  String? backUp;
  String? clearance;
  String? salaryAdvance;
  String? otherAdvance;
  String? pettyCash;
  String? settleExpenses;
  String? itDoc;
  String? happyAccount;
  String? laptop;
  String? cardAccessories;
  String? sapLogin;
  String? emailId;
  String? loginId;
  String? idAccessCard;
  String? drawKey;
  String? businessCard;
  String? headset;
  String? sim;
  String? stationaryItems;
  String? chargerCable;
  String? medicalClaim;
  String? exitInterview;
  String? resignMail;
  String? noticePeriod;
  String? relevant;
  String? companyProperty;
  String? otherHandover;
  String? userID;
  var _noDueFormKey = GlobalKey<FormState>();


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getUserID();

  }

  getUserID() async{
    final prefs=await SharedPreferences.getInstance();

    userID = prefs.getString("id");
    print("$userID userId");
  }

  @override
  Widget build(BuildContext context) {
    return
      BlocProvider(
          create: (context) {
            return SalaryBloc();
          },
          child: BlocListener<SalaryBloc, SalaryState>(
              listener: (context, state) {
                if(state is CreateNoDueRequestSuccessState){
                  print("$state success state");
                  showDialog<bool>(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        shape: const RoundedRectangleBorder(
                            borderRadius: BorderRadius.all(Radius.circular(10.0))),
                        title: CommonUI().myText(
                            text: 'UDS',
                            textAlign: TextAlign.center,
                            color: AppTheme.primaryColor2),
                        actionsAlignment: MainAxisAlignment.end,
                        content: CommonUI().myText(
                            text: 'Form submitted successfully!!',
                            fontWeight: FontWeight.normal,
                            textAlign: TextAlign.center,
                            color: AppTheme.primaryColor2,
                            maxLines: 2),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                              Navigator.pop(context);

                            },
                            child: CommonUI().myText(
                              text: 'Ok',
                            ),
                          ),
                        ],
                      );
                    },
                  );
                }
                if(state is CreateNoDueRequestErrorState){
                  print("${state.error} error");
                }
              }, child:
          BlocBuilder<SalaryBloc, SalaryState>(builder: (context, state) {

            return Scaffold(
              appBar: AppBar(
                backgroundColor: AppTheme.whiteColor,
                automaticallyImplyLeading: false,
                elevation: 0,
                title: Row(
                  children: [
                    IconButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        icon: Icon(Icons.arrow_back_ios)),
                    Gap(2.w),
                    CommonUI().myText(
                      text: "NoDue Form",
                    ),
                  ],
                ),
              ),
              body: SingleChildScrollView(
                child: Padding(
                  padding: EdgeInsets.fromLTRB(4.w, 2.h, 4.w, 2.h),
                  child: Form(
                    key: _noDueFormKey,
                    child: Column(
                      children: [
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Name of Employee "),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empNameController, hinttext: ""),
                        Gap(3.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Employee Code"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empCodeController, hinttext: ""),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Designation"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empDesignationController, hinttext: ""),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Location"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empLocationController, hinttext: ""),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Department"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empDepartmentController, hinttext: ""),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Date of Join"),
                              ],
                            )),
                        Gap(1.h),
                        // CommonUI.formField(
                        //     editingController: _empDateJoiningController, hinttext: ""),
                        Builder(
                            builder: (context) {
                              return DropdownDatePicker(
                                // inputDecoration: InputDecoration(
                                //   border: BorderSide.none
                                // ),
                                boxDecoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(6.0),
                                    color: AppTheme.grey.withOpacity(0.1)),

                                locale: "en",

                                isDropdownHideUnderline: true, // optional
                                isFormValidator: true, // optional
                                startYear: 1900, // optional
                                endYear: 2024, // optional
                                width: 16, // optional
                                selectedDay:  _selectedJoiningDay, // optional
                                selectedMonth: _selectedJoiningMonth, // optional
                                selectedYear: _selectedJoiningYear, // optional
                                onChangedDay: (value) {
                                  _selectedJoiningDay = int.parse(value!);
                                  print('onChangedDay: $value');
                                },
                                onChangedMonth: (value) {
                                  _selectedJoiningMonth = int.parse(value!);
                                  print('onChangedMonth: $value');
                                },
                                onChangedYear: (value) {
                                  _selectedJoiningYear = int.parse(value!);
                                  print('onChangedYear: $value');

                                  // calculateAge(  DateTime(_selectedYear!, _selectedMonth!, _selectedDay!));
                                },

                                showDay: true,
                                monthFlex: 4, // optional
                                dayFlex: 3,
                                yearFlex: 4, // optional
                                hintDay: 'Day', // optional
                                hintMonth: 'Month', // optional
                                hintYear: 'Year', // optional
                                hintTextStyle: TextStyle(color: Colors.grey), // optional
                              );
                            }
                        ),

                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Date of Relieving"),
                              ],
                            )),
                        Gap(1.h),
                        Builder(
                            builder: (context) {
                              return DropdownDatePicker(
                                // inputDecoration: InputDecoration(
                                //   border: BorderSide.none
                                // ),
                                boxDecoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(6.0),
                                    color: AppTheme.grey.withOpacity(0.1)),

                                locale: "en",

                                isDropdownHideUnderline: true, // optional
                                isFormValidator: true, // optional
                                startYear: 1900, // optional
                                endYear: 2024, // optional
                                width: 16, // optional
                                selectedDay:  _selectedRelievingDay, // optional
                                selectedMonth: _selectedRelievingMonth, // optional
                                selectedYear: _selectedRelievingYear, // optional
                                onChangedDay: (value) {
                                  _selectedRelievingDay = int.parse(value!);
                                  print('onChangedDay: $value');
                                },
                                onChangedMonth: (value) {
                                  _selectedRelievingMonth = int.parse(value!);
                                  print('onChangedMonth: $value');
                                },
                                onChangedYear: (value) {
                                  _selectedRelievingYear = int.parse(value!);
                                  print('onChangedYear: $value');

                                  // calculateAge(  DateTime(_selectedYear!, _selectedMonth!, _selectedDay!));
                                },

                                showDay: true,
                                monthFlex: 4, // optional
                                dayFlex: 3,
                                yearFlex: 4, // optional
                                hintDay: 'Day', // optional
                                hintMonth: 'Month', // optional
                                hintYear: 'Year', // optional
                                hintTextStyle: TextStyle(color: Colors.grey), // optional
                              );
                            }
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Official Email"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empOfficialMailIdController,

                            hinttext: "",
                            validator:
                                (value) {
                              if (value!.isNotEmpty && isValidEmailAddress(value)) {
                                return null;
                              }


                              return "Please Enter valid Email";
                            }),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Personal Contact"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            editingController: _empPersonalContactController,
                            keyboardType: TextInputType.number,
                            validator:
                            (value) {
                if (value!.isNotEmpty) {
                return null;
                }


                return "Please Enter valid PhoneNumber";
                },
                            maxLength: 10,
                            hinttext: ""),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Personal Email"),
                              ],
                            )),
                        Gap(1.h),
                        CommonUI.formField(
                            validator:
                                (value) {
                              if (value!.isNotEmpty && isValidEmailAddress(value)) {
                                return null;
                              }


                              return "Please Enter valid Email or PhoneNumber";
                            },
                            editingController: _empPersonalEmailController, hinttext: ""),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(
                                    text: "Dept Head/ Reporting Manager",
                                    fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "Knowledge Transfer", fontSize: 11.sp),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // initialValue: "name4",
                          // controller: _knowledgeController,
                          clearOption: true,
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                                name: 'No',
                                value: "no",
                                toolTipMsg:
                                "DropDownButton is a widget that we can use to select one unique value from a set of values"),
                            DropDownValueModel(name: 'Nil', value: "null"),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            setState(() {
                              kt = val.value;
                            });

                          },
                        ),
                        Gap(3.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(text: "Back up", fontSize: 11.sp),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            setState(() {
                              backUp = val.value;
                            });
                          },
                        ),
                        Gap(3.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text:
                                      "Clearance for short payments/deductions/outstanding if any",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _ClearanceController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            setState(() {
                              clearance = val.value;
                            });
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "Payroll", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(3.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Salary Advance",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _salaryAdvanceController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            setState(() {
                              salaryAdvance = val.value;
                            });
                          },
                        ),
                        Gap(3.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Any other advance",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _otherAdvanceController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            otherAdvance = val.value;
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "Finance", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Petty cash advances",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _pettyCashController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            pettyCash = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Settlement of expenses",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _settleExpensesController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            settleExpenses = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Submission of IT Documents",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            itDoc = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Happy Account Closure",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            happyAccount = val.value;
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "IT", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Laptop",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            laptop = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Data card & Accessories",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            cardAccessories = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "SAP Login Id's",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            sapLogin = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Email Id",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            emailId = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Login Id's",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            loginId = val.value;
                          },

                        ),

                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "Admin", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "ID Card & Access Card",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            idAccessCard = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Draw Keys",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            drawKey = val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Business Card",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            businessCard = val.value;
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(
                                    text: "Purchase", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Blackberry / Phone handset",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            headset =val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Sim Card",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            sim =val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Stationary Items",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            stationaryItems =val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Charger & Datacable",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            chargerCable = val.value;
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI().myText(
                                    text: "Mediclaim", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Mediclaim",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            medicalClaim = val.value;
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "HR", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Exit Interview",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            exitInterview =val.value;
                          },
                        ),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Resignation Mail / Copy",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            resignMail = val.value;
                          },
                        ),

                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Notice Period served",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            noticePeriod = val.value;
                          },
                        ),
                        Gap(4.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                CommonUI()
                                    .myText(text: "Operations", fontWeight: FontWeight.w600),
                              ],
                            )),
                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Relevant Correspondence",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        Gap(2.h),

                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: 'no',
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            relevant =val.value;
                          },
                        ),

                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Uniform / shoes or any other company property",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          // controller: _backupController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: "no",
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            companyProperty = val.value;
                          },
                        ),

                        Gap(2.h),
                        Align(
                            alignment: Alignment.topLeft,
                            child: Row(
                              children: [
                                SizedBox(
                                  width: 90.w,
                                  child: CommonUI().myText(
                                      overflow: TextOverflow.visible,
                                      lineHeight: 0.2.h,
                                      text: "Any other handover",
                                      fontSize: 11.sp),
                                ),
                              ],
                            )),
                        Gap(1.h),
                        DropDownTextField(
                          textStyle: TextStyle(fontSize: 10.sp),
                          // initialValue: "name4",
                          controller: _otherHandOverController,
                          clearOption: true,
                          textFieldDecoration: InputDecoration(
                            filled: true,
                            fillColor: AppTheme.grey.withOpacity(0.1),
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                              borderRadius:
                              BorderRadius.circular(10.0), // Adjust the border radius
                            ),
                          ),
                          // enableSearch: true,
                          // dropdownColor: Colors.green,
                          searchDecoration: const InputDecoration(hintText: "select one"),
                          validator: (value) {
                            if (value!.isEmpty) {
                              return "Required field";
                            } else {
                              return null;
                            }
                          },
                          dropDownItemCount: 6,

                          dropDownList: const [
                            DropDownValueModel(name: 'Yes', value: 'yes'),
                            DropDownValueModel(
                              name: 'No',
                              value: "no",
                            ),
                            DropDownValueModel(name: 'Nil', value: null),
                          ],
                          onChanged: (val) {
                            print(val.value);
                            print(val.name);
                            print("selected value is $val");
                            otherHandover =val.value;
                          },
                        ),
                        Gap(4.h),
                      ],
                    ),
                  ),
                ),
              ),
              bottomNavigationBar: Padding(
                padding:  EdgeInsets.fromLTRB(5.w,2.h,5.w,2.h),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CommonUI.buttonContainer(
                        width: 60.w,
                        height: 4.h,
                        onPressed: (){
                          var form = _noDueFormKey.currentState;
                          if (form?.validate() ?? true) {

                            var data = CreateNoDueRequestObject(
                                location: _empLocationController.text.trim(),
                                dateOfRelieving: DateTime(_selectedRelievingYear!,_selectedRelievingMonth!,_selectedRelievingDay!).toString().split(" ")[0],
                                officialEmail: _empOfficialMailIdController.text.trim(),
                                kt: kt.toString(),
                                backUp:  backUp.toString(),
                                clearance: clearance.toString(),
                                salaryAdvance: salaryAdvance.toString(),
                                otherAdvance: otherAdvance.toString(),
                                pettyCash: pettyCash.toString(),
                                settleExpenses: settleExpenses.toString(),
                                itDoc: itDoc.toString(),
                                happyAccount: happyAccount.toString(),
                                laptop: laptop.toString(),
                                cardAccessories : cardAccessories.toString(),
                                sapLogin : sapLogin.toString(),
                                emailId : emailId.toString(),
                                loginId : loginId.toString(),
                                idAccessCard : idAccessCard.toString(),
                                drawKey : drawKey.toString(),
                                businessCard : businessCard.toString(),
                                headset : headset.toString(),
                                sim : sim.toString(),
                                stationaryItems : stationaryItems.toString(),
                                chargerCable : chargerCable.toString(),
                                medicalClaim : medicalClaim.toString(),
                                exitInterview : exitInterview.toString(),
                                resignMail : resignMail.toString(),
                                noticePeriod: noticePeriod.toString(),
                                relevant: relevant.toString(),
                                companyProperty : companyProperty.toString(),
                                otherHandover : otherHandover.toString(),
                                userId : userID!


                            );

                            BlocProvider.of<SalaryBloc>(context).add(CreateNoDueRequestEvent(context, data));

                          }
                          else{
                            print("formstate error");
                          }



                                  },
                        file:
                        Center(child: CommonUI().myText(text: "Submit",
                            color: AppTheme.whiteColor)))
                  ],
                ),
              ),
            );
  })));


  }

  bool isValidPhoneNumber(String value) {
    // Phone number pattern: +1234567890, 1234567890, +12 345-678 90, etc.
    final RegExp phoneRegex =
    RegExp(r'^(\+\d{1,2})?[\s.-]?\(?\d{1,4}\)?[\s.-]?\d{1,10}$');
    bool isLengthValid = value.replaceAll(RegExp(r'[^\d]'), '').length <= 10;

    return phoneRegex.hasMatch(value) && isLengthValid;
    // return phoneRegex.hasMatch(value);
  }

  bool isValidEmailAddress(String value) {
    // Email address pattern
    final RegExp emailRegex = RegExp(
      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
    );
    return emailRegex.hasMatch(value);
  }
}
